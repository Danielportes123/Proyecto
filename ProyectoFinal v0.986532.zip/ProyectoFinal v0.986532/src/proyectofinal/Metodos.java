/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectofinal;

/**
 *
 * @author luiggi paredes
 */
public class Metodos {
    public double multiplicar(double v1, double v2){
      return v1*v2;
  }   
}
